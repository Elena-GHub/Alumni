# Alumni 

Requirements 
-----------
* PHP
* Laravel
* MySQL
* Bootstrap
* Vue.js

Department and sections 
-----------------------
* Foro/Faq - Clean Coders
* Ofertas de Trabajo / Proyectos Propios - Slow Coders
* Perfiles / Usuario / Eventos - InterCoders
* Empresas - Five Code
* Design Ui/Ux - Stranger Strings


