<template>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1>Home</h1>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "home",
        props: ['app']
    }
</script>

<style scoped>

</style>